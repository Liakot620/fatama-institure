<footer class="footer">
    <div class="footer-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 offset-lg-0 col-md-8 offset-md-2 col-10 offset-1">
                    <div class="footer-copyright c-grey-1">
                        <h6><?php echo esc_html( __( 'Copyright', 'orions' ) ); ?> &copy; <?php echo esc_html( __( 'Orions', 'orions' ) .  ' ' . date('Y') ); ?></h6>
                    </div>
                </div>
            </div>
        </div>           
    </div> 
</footer>